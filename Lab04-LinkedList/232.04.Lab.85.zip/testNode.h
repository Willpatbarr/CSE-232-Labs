/***********************************************************************
 * Header:
 *    TEST NODE
 * Summary:
 *    Unit tests for node
 * Author
 *    Br. Helfrich
 ************************************************************************/

#pragma once

#ifdef DEBUG

#include "node.h"
#include "unitTest.h"
#include <cassert>
#include <memory>

class TestNode : public UnitTest
{
public:
   void run()
   {
      reset();

      // Construct
      test_create_default();
      test_create_value();
      test_copy_nullptr();
      test_copy_one();
      test_copy_standard();

      // Assign
      test_assign_emptyToEmpty();
      test_assign_standardToEmpty();
      test_assign_emptyToStandard();
      test_assign_smallToBig();
      test_assign_bigToSmall();
      test_swap_emptyEmpty();
      test_swap_emptyStandard();
      test_swap_standardEmpty();
      test_swap_oneTwo();

      // Insert
      test_insert_emptyBefore();
      test_insert_emptyAfter();
      test_insert_frontBefore();
      test_insert_frontAfter();
      test_insert_backBefore();
      test_insert_backAfter();
      test_insert_middleBefore();
      test_insert_middleAfter();
      
      // Remove
      test_remove_nullptr();
      test_remove_front();
      test_remove_back();
      test_remove_middle();
      test_clear_nullptr();
      test_clear_one();
      test_clear_standard();

      // Status
      test_size_empty();
      test_size_standard();
      test_size_standardMiddle();
      
      report("Node");
   }
   
   /***************************************
    * CONSTRUCTOR
    ***************************************/
   
   // default constructor
   void test_create_default()
   {  // setup
      std::allocator<Node> alloc;
      Node n;
      n.pNext = (Node *)0xBADF00D1;
      n.pPrev = (Node *)0xBADF00D2;
      // exercise
      alloc.construct(&n); // the constructor is called explicitly
      // verify
      assertEmptyFixture(&n);
   }  // teardown
   
   // non-default constructor that initializes with a value.
   void test_create_value()
   {  // setup
      std::allocator<Node> alloc;
      Node n;
      n.pNext = (Node*)0xBADF00D1;
      n.pPrev = (Node*)0xBADF00D2;
      int s(99);
      // exercise
      alloc.construct(&n, s); // the constructor is called explicitly
      // verify
      //    +----+
      //    | 99 |
      //    +----+
      assertUnit(n.data == int(99));
      n.data = int();
      assertEmptyFixture(&n);
   }  // teardown
      
   /***************************************
    * COPY
    ***************************************/
   
   // copy with a nullptr pointer
   void test_copy_nullptr()
   {  // setup
      Node * pSrc = nullptr;
      Node * pDes = nullptr;
      // exercise
      pDes = copy(pSrc);
      // verify
      assertUnit(pDes == nullptr);
      assertUnit(pSrc == nullptr);
   }  // teardown

   // copy a single node in insolation
   void test_copy_one()
   {  // setup
      //    +----+
      //    | 26 |
      //    +----+
      Node * pSrc = new Node  (int(26));
      Node * pDes = nullptr;
      // exercise
      pDes = copy(pSrc);
      // verify
      assertUnit(pSrc != pDes);
      //    +----+
      //    | 26 |
      //    +----+
      assertUnit(pSrc != nullptr);
      if (pSrc)
      {
         assertUnit(pSrc->data == int(26));
         assertUnit(pSrc->pNext == nullptr);
         assertUnit(pSrc->pPrev == nullptr);
      }
      //    +----+
      //    | 26 |
      //    +----+
      assertUnit(pDes != nullptr);
      if (pDes)
      {
         assertUnit(pDes->data == int(26));
         assertUnit(pDes->pNext == nullptr);
         assertUnit(pDes->pPrev == nullptr);
      }
      // teardown
      teardownStandardFixture(pSrc);
      teardownStandardFixture(pDes);
   }
   
   // copy the standard fixture: three nodes.
   void test_copy_standard()
   {  // setup
      //     p11      p26      p31
      //    +----+   +----+   +----+
      //    | 11 | - | 26 | - | 31 |
      //    +----+   +----+   +----+
      Node * p11, * p26, * p31;
      setupStandardFixture(p11, p26, p31);
      Node * pDes = nullptr;
      // exercise
      pDes = copy(p11);
      // verify
      assertUnit(p11 != pDes);
      if(pDes)
      { 
         assertUnit(p26 != pDes->pNext);
         if (p31 && pDes->pNext)
            assertUnit(p31->pNext != pDes->pNext->pNext);
      }
      //     p11   
      //    +----+   +----+   +----+
      //    | 11 | - | 26 | - | 31 |
      //    +----+   +----+   +----+
      assertStandardFixture(p11);
      //     pDes
      //    +----+   +----+   +----+
      //    | 11 | - | 26 | - | 31 |
      //    +----+   +----+   +----+
      assertStandardFixture(pDes);
      // teardown
      teardownStandardFixture(p11);
      teardownStandardFixture(pDes);
   }

   /***************************************
    * ASSIGN
    ***************************************/

   // assign an empty list to an empty list
   void test_assign_emptyToEmpty()
   {  // setup
      Node * pSrc = nullptr;
      Node * pDes = nullptr;      // exercise
      assign(pDes, pSrc);
      // verify
      assertUnit(pDes == nullptr);
      assertUnit(pSrc == nullptr);
   }  // teardown

   // assign the standard fixture onto an empty linked list
   void test_assign_standardToEmpty()
   {  // setup
      //     p11      p26      p31
      //    +----+   +----+   +----+
      //    | 11 | - | 26 | - | 31 |
      //    +----+   +----+   +----+
      Node * p11, * p26, * p31;
      setupStandardFixture(p11, p26, p31);
      Node * pDes = nullptr;
      // exercise
      assign(pDes, p11);
      // verify
      assertUnit(pDes != p11);
      //     p11   
      //    +----+   +----+   +----+
      //    | 11 | - | 26 | - | 31 |
      //    +----+   +----+   +----+
      assertStandardFixture(p11);
      //     pDes
      //    +----+   +----+   +----+
      //    | 11 | - | 26 | - | 31 |
      //    +----+   +----+   +----+
      assertStandardFixture(pDes);
      // teardown
      teardownStandardFixture(p11);
      teardownStandardFixture(pDes);
   }

   // assign an empty linked list onto a standard fixturew
   void test_assign_emptyToStandard()
   {  // setup
      const Node * pSrc = nullptr;
      //     p11      p26      p31
      //    +----+   +----+   +----+
      //    | 11 | - | 26 | - | 31 |
      //    +----+   +----+   +----+
      Node * p11, * p26, * p31;
      setupStandardFixture(p11, p26, p31);
      // exercise
      assign(p11, pSrc);
      // verify
      assertUnit(p11 == nullptr);
      assertUnit(pSrc == nullptr);
   }  // teardown

   // assign a small linked list to a big one
   void test_assign_smallToBig()
   {  // setup
      //     p11      p26      p31
      //    +----+   +----+   +----+
      //    | 11 | - | 26 | - | 31 |
      //    +----+   +----+   +----+
      Node * p11, * p26, * p31;
      setupStandardFixture(p11, p26, p31);
      //     p67      p89  
      //    +----+   +----+
      //    | 67 | - | 89 |
      //    +----+   +----+
      Node * p67, * p89;
      p67 = new Node (int(67));
      p89 = new Node (int(89));
      p67->pNext = p89;
      p89->pPrev = p67;
      // exercise
      assign(p11, p67);
      // verify
      assertUnit(p11 != p67);
      //     p11      p26  
      //    +----+   +----+
      //    | 67 | - | 89 |
      //    +----+   +----+
      assertUnit(p11 != nullptr);
      if (p11)
      {
         assertUnit(p11->data == int(67));
         assertUnit(p11->pPrev == nullptr);
         assertUnit(p11->pNext == p26);
      }
      assertUnit(p26 != nullptr);
      if (p26)
      {
         assertUnit(p26->data == int(89));
         assertUnit(p26->pPrev == p11);
         assertUnit(p26->pNext == nullptr);
      }
      //     p67      p89  
      //    +----+   +----+
      //    | 67 | - | 89 |
      //    +----+   +----+
      assertUnit(p67 != nullptr);
      if (p67)
      {
         assertUnit(p67->data == int(67));
         assertUnit(p67->pPrev == nullptr);
         assertUnit(p67->pNext == p89);
      }
      assertUnit(p89 != nullptr);
      if (p89)
      {
         assertUnit(p89->data == int(89));
         assertUnit(p89->pPrev == p67);
         assertUnit(p89->pNext == nullptr);
      }
      // teardown
      teardownStandardFixture(p11);
      teardownStandardFixture(p67);
   }

   // assign a big linked list to a small one
   void test_assign_bigToSmall()
   {  // setup
      //     p11      p26      p31
      //    +----+   +----+   +----+
      //    | 11 | - | 26 | - | 31 |
      //    +----+   +----+   +----+
      Node * p11, * p26, * p31;
      setupStandardFixture(p11, p26, p31);
      //     p67      p89  
      //    +----+   +----+
      //    | 67 | - | 89 |
      //    +----+   +----+
      Node * p67, * p89;
      p67 = new Node (int(67));
      p89 = new Node (int(89));
      p67->pNext = p89;
      p89->pPrev = p67;
      // exercise
      assign(p67, p11);
      // verify
      assertUnit(p11 != p67);
      //     p11   
      //    +----+   +----+   +----+
      //    | 11 | - | 26 | - | 31 |
      //    +----+   +----+   +----+
      assertStandardFixture(p11);
      //     p67
      //    +----+   +----+   +----+
      //    | 11 | - | 26 | - | 31 |
      //    +----+   +----+   +----+
      assertStandardFixture(p67);
      // teardown
      teardownStandardFixture(p11);
      teardownStandardFixture(p67);
   }

   /***************************************
    * SWAP
    ***************************************/

   // swap two empty pointers
   void test_swap_emptyEmpty()
   {  // setup
      Node * pLHS = nullptr;
      Node * pRHS = nullptr;
      // exercise
      swap(pLHS, pRHS);
      // verify
      assertUnit(pLHS == nullptr);
      assertUnit(pRHS == nullptr);
   }  // teardown

   // swap an empty fixture with the standard fixture
   void test_swap_emptyStandard()
   {  // setup
      Node * pLHS = nullptr;
      //     p11      p26      p31
      //    +----+   +----+   +----+
      //    | 11 | - | 26 | - | 31 |
      //    +----+   +----+   +----+
      Node * p11, * p26, * p31;
      setupStandardFixture(p11, p26, p31);
      // exercise
      swap(pLHS, p11);
      // verify
      //     pLHS
      //    +----+   +----+   +----+
      //    | 11 | - | 26 | - | 31 |
      //    +----+   +----+   +----+
      assertStandardFixture(pLHS);
      assertUnit(p11 == nullptr);
      // teardown
      teardownStandardFixture(pLHS);
   }

   // swap an empty fixture with the standard fixture
   void test_swap_standardEmpty()
   {  // setup
      //     p11      p26      p31
      //    +----+   +----+   +----+
      //    | 11 | - | 26 | - | 31 |
      //    +----+   +----+   +----+
      Node * p11, * p26, * p31;
      setupStandardFixture(p11, p26, p31);
      Node * pRHS = nullptr;
      // exercise
      swap(p11, pRHS);
      // verify
      //     pRHS
      //    +----+   +----+   +----+
      //    | 11 | - | 26 | - | 31 |
      //    +----+   +----+   +----+
      assertStandardFixture(pRHS);
      assertUnit(p11 == nullptr);
      // teardown
      teardownStandardFixture(pRHS);
   } 
   
   // swap two non-empty lists
   void test_swap_oneTwo()
   {  // setup
      //     p11      p26      p31
      //    +----+   +----+   +----+
      //    | 11 | - | 26 | - | 31 |
      //    +----+   +----+   +----+
      Node * p11, * p26, * p31;
      setupStandardFixture(p11, p26, p31);
      //     p67      p89  
      //    +----+   +----+
      //    | 67 | - | 89 |
      //    +----+   +----+
      Node * p67, * p89;
      p67 = new Node (int(67));
      p89 = new Node (int(89));
      p67->pNext = p89;
      p89->pPrev = p67;
      // exercise
      swap(p11, p67);
      // verify
      //     p67
      //    +----+   +----+   +----+
      //    | 11 | - | 26 | - | 31 |
      //    +----+   +----+   +----+
      assertStandardFixture(p67);
      //     p11
      //    +----+   +----+
      //    | 67 | - | 89 |
      //    +----+   +----+
      assertUnit(p11 != nullptr);
      if (p11)
      {
         assertUnit(p11->data == int(67));
         assertUnit(p11->pPrev == nullptr);
         assertUnit(p11->pNext == p89);
      }

      assertUnit(p89 != nullptr);
      if (p89)
      {
         assertUnit(p89->data == int(89));
         assertUnit(p89->pPrev == p11);
         assertUnit(p89->pNext == nullptr);
      }
      // teardown
      teardownStandardFixture(p67);
      teardownStandardFixture(p11);
   } 

   /***************************************
    * REMOVE
    ***************************************/
   
   // attempt to remove from a nullptr pointer
   void test_remove_nullptr()
   {  // setup
      Node * pHead = nullptr;
      Node * pReturn = nullptr;
      // exercise
      pReturn = remove(pHead);
      // verify
      assertUnit(pHead == nullptr);
      assertUnit(pReturn == nullptr);
   }  // teardown
   
   // attempt to remove from the front of the standard fixture
   void test_remove_front()
   {  // setup
      //     p11      p26      p31
      //    +----+   +----+   +----+
      //    | 11 | - | 26 | - | 31 |
      //    +----+   +----+   +----+
      //     pRemove
      Node * p11, * p26, * p31;
      setupStandardFixture(p11, p26, p31);
      Node * pReturn = nullptr;
      Node * pRemove = p11;
      // exercise
      pReturn = remove(pRemove);
      // verify
      //    pReturn
      //      p26      p31
      //    +----+   +----+
      //    | 26 | - | 31 |
      //    +----+   +----+
      assertUnit(pReturn == p26);
      assertUnit(nullptr != p26);
      if (p26)
      { 
         assertUnit(p26->data == int(26));
         assertUnit(p26->pNext == p31);
         assertUnit(p26->pPrev == nullptr);
      }
      assertUnit(nullptr != p31);
      if (p31)
      {
         assertUnit(p31->data == int(31));
         assertUnit(p31->pNext == nullptr);
         assertUnit(p31->pPrev == p26);
      }
      // teardown
      teardownStandardFixture(p26);
   }
   
   // remove from the back of the standard fixture
   void test_remove_back()
   {  // setup
      //     p11      p26      p31
      //    +----+   +----+   +----+
      //    | 11 | - | 26 | - | 31 |
      //    +----+   +----+   +----+
      //                       pRemove
      Node * p11, * p26, * p31;
      setupStandardFixture(p11, p26, p31);
      Node * pReturn = nullptr;
      Node * pRemove = p31;
      // exercise
      pReturn = remove(pRemove);
      // verify
      //             pReturn
      //      p11      p26
      //    +----+   +----+
      //    | 11 | - | 26 |
      //    +----+   +----+
      assertUnit(pReturn == p26);

      assertUnit(p26 != nullptr);
      if (p26)
      {
         assertUnit(p26->data == int(26));
         assertUnit(p26->pNext == nullptr);
         assertUnit(p26->pPrev == p11);
      }
      assertUnit(p11 != nullptr);
      if (p11)
      {
         assertUnit(p11->data == int(11));
         assertUnit(p11->pNext == p26);
         assertUnit(p11->pPrev == nullptr);
      }
      // teardown
      teardownStandardFixture(p11);
   }

   // remove from the middle of the standard fixture
   void test_remove_middle()
   {  // setup
      //     p11      p26      p31
      //    +----+   +----+   +----+
      //    | 11 | - | 26 | - | 31 |
      //    +----+   +----+   +----+
      //             pRemove
      Node * p11, * p26, * p31;
      setupStandardFixture(p11, p26, p31);
      Node * pReturn = nullptr;
      Node * pRemove = p26;
      // exercise
      pReturn = remove(pRemove);
      // verify
      //    pReturn
      //    +----+   +----+
      //    | 11 | - | 31 |
      //    +----+   +----+
      assertUnit(pReturn == p11);

      assertUnit(p11 != nullptr);
      if (p11)
      {
         assertUnit(p11->data == int(11));
         assertUnit(p11->pNext == p31);
         assertUnit(p11->pPrev == nullptr);
      }

      assertUnit(p31 != nullptr);
      if (p31)
      {
         assertUnit(p31->data == int(31));
         assertUnit(p31->pNext == nullptr);
         assertUnit(p31->pPrev == p11);
      }
      // teardown
      teardownStandardFixture(p11);
   }
   
   /***************************************
    * INSERT
    ***************************************/
   
   // insert into an empty linked list with the before option set
   void test_insert_emptyBefore()
   {  // setup
      Node * pInsert = nullptr;
      Node * pReturn = nullptr;
      int s(99);
      // exercise
      pReturn = insert(pInsert, s, false /*after*/);
      // verify
      
      //    pReturn
      //    +----+
      //    | 99 |
      //    +----+
      assertUnit(pReturn != nullptr);
      if (pReturn)
      {
         assertUnit(pReturn->data == int(99));
         assertUnit(pReturn->pPrev == nullptr);
         assertUnit(pReturn->pNext == nullptr);
      }
      assertUnit(pInsert == nullptr);
      // teardown
      teardownStandardFixture(pReturn);
   }

   // insert into an empty linked list with the after option set
   void test_insert_emptyAfter()
   {  // setup
      Node * pInsert = nullptr;
      Node * pReturn = nullptr;
      int s(99);
      // exercise
      pReturn = insert(pInsert, s, true /*after*/);
      // verify
      //    pReturn
      //    +----+
      //    | 99 |
      //    +----+
      assertUnit(pReturn != nullptr);
      if (pReturn)
      {
         assertUnit(pReturn->data == int(99));
         assertUnit(pReturn->pPrev == nullptr);
         assertUnit(pReturn->pNext == nullptr);
      }
      assertUnit(pInsert == nullptr);
      // teardown
      teardownStandardFixture(pReturn);
   }

   // insert into the front of the standard fixture with the after option set
   void test_insert_frontBefore()
   {  // setup
      //     p11      p26      p31
      //    +----+   +----+   +----+
      //    | 11 | - | 26 | - | 31 |
      //    +----+   +----+   +----+
      Node * p11, * p26, * p31;
      setupStandardFixture(p11, p26, p31);
      Node * pReturn = nullptr;
      int s(99);
      // exercise
      pReturn = insert(p11, s, false /*after*/);
      // verify
      //     pReturn    p11      p26      p31
      //     +----+   +----+   +----+   +----+
      //     | 99 | - | 11 | - | 26 | - | 31 |
      //     +----+   +----+   +----+   +----+
      assertUnit(pReturn != nullptr);
      if (pReturn)
      {
         assertUnit(pReturn->data == int(99));
         assertUnit(pReturn->pNext == p11);
         assertUnit(pReturn->pPrev == nullptr);
      }

      assertUnit(p11 != nullptr);
      if (p11)
      {
         assertUnit(p11->data == int(11));
         assertUnit(p11->pPrev == pReturn);
         assertUnit(p11->pNext == p26);
      }

      assertUnit(p26 != nullptr);
      if (p26)
      {
         assertUnit(p26->data == int(26));
         assertUnit(p26->pPrev == p11);
         assertUnit(p26->pNext == p31);
      }

      assertUnit(p31 != nullptr);
      if (p31)
      {
         assertUnit(p31->data == int(31));
         assertUnit(p31->pPrev == p26);
         assertUnit(p31->pNext == nullptr);
      }
      // teardown
      delete pReturn;
      delete p11;
      delete p26;
      delete p31;
   }
   
   // insert into the front of the standard fixture with the before option set
   void test_insert_frontAfter()
   {  // setup
      //     p11      p26      p31
      //    +----+   +----+   +----+
      //    | 11 | - | 26 | - | 31 |
      //    +----+   +----+   +----+
      Node * p11, * p26, * p31;
      setupStandardFixture(p11, p26, p31);
      Node * pReturn = nullptr;
      int s(99);
      // exercise
      pReturn = insert(p11, s, true /*after*/);
      // verify
      //       p11    pReturn   p26      p31
      //     +----+   +----+   +----+   +----+
      //     | 11 | - | 99 | - | 26 | - | 31 |
      //     +----+   +----+   +----+   +----+
      assertUnit(p11 != nullptr);
      if (p11)
      {
         assertUnit(p11->data == int(11));
         assertUnit(p11->pPrev == nullptr);
         assertUnit(p11->pNext == pReturn);
      }

      assertUnit(pReturn != nullptr);
      if (pReturn)
      {
         assertUnit(pReturn->data == int(99));
         assertUnit(pReturn->pNext == p26);
         assertUnit(pReturn->pPrev == p11);
      }

      assertUnit(p26 != nullptr);
      if (p26)
      {
         assertUnit(p26->data == int(26));
         assertUnit(p26->pPrev == pReturn);
         assertUnit(p26->pNext == p31);
      }

      assertUnit(p31 != nullptr);
      if (p31)
      {
         assertUnit(p31->data == int(31));
         assertUnit(p31->pPrev == p26);
         assertUnit(p31->pNext == nullptr);
      }
      // teardown
      delete pReturn;
      delete p11;
      delete p26;
      delete p31;
   }

   // insert into the back of the standard fixture with the before option set
   void test_insert_backBefore()
   {  // setup
      //     p11      p26      p31
      //    +----+   +----+   +----+
      //    | 11 | - | 26 | - | 31 |
      //    +----+   +----+   +----+
      Node * p11, * p26, * p31;
      setupStandardFixture(p11, p26, p31);
      Node * pReturn = nullptr;
      int s(99);
      // exercise
      pReturn = insert(p31, s, false /*after*/);
      // verify
      //       p11      p26    pReturn   p31
      //     +----+   +----+   +----+   +----+
      //     | 11 | - | 26 | - | 99 | - | 31 |
      //     +----+   +----+   +----+   +----+
      assertUnit(p11 != nullptr);
      if (p11)
      {
         assertUnit(p11->data == int(11));
         assertUnit(p11->pPrev == nullptr);
         assertUnit(p11->pNext == p26);
      }

      assertUnit(p26 != nullptr);
      if (p26)
      {
         assertUnit(p26->data == int(26));
         assertUnit(p26->pPrev == p11);
         assertUnit(p26->pNext == pReturn);
      }

      assertUnit(pReturn != nullptr);
      if (pReturn)
      {
         assertUnit(pReturn->data == int(99));
         assertUnit(pReturn->pNext == p31);
         assertUnit(pReturn->pPrev == p26);
      }

      assertUnit(p31 != nullptr);
      if (p31)
      {
         assertUnit(p31->data == int(31));
         assertUnit(p31->pPrev == pReturn);
         assertUnit(p31->pNext == nullptr);
      }
      // teardown
      delete pReturn;
      delete p11;
      delete p26;
      delete p31;
   }

   // insert into the back of the standard fixture with the after option set
   void test_insert_backAfter()
   {  // setup
      //     p11      p26      p31
      //    +----+   +----+   +----+
      //    | 11 | - | 26 | - | 31 |
      //    +----+   +----+   +----+
      Node * p11, * p26, * p31;
      setupStandardFixture(p11, p26, p31);
      Node * pReturn = nullptr;
      int s(99);
      // exercise
      pReturn = insert(p31, s, true /*after*/);
      // verify
      //       p11      p26      p31    pReturn  
      //     +----+   +----+   +----+   +----+
      //     | 11 | - | 26 | - | 31 | - | 99 |
      //     +----+   +----+   +----+   +----+
      assertUnit(p11 != nullptr);
      if (p11)
      {
         assertUnit(p11->data == int(11));
         assertUnit(p11->pPrev == nullptr);
         assertUnit(p11->pNext == p26);
      }

      assertUnit(p26 != nullptr);
      if (p26)
      {
         assertUnit(p26->data == int(26));
         assertUnit(p26->pPrev == p11);
         assertUnit(p26->pNext == p31);
      }

      assertUnit(p31 != nullptr);
      if (p31)
      {
         assertUnit(p31->data == int(31));
         assertUnit(p31->pPrev == p26);
         assertUnit(p31->pNext == pReturn);
      }

      assertUnit(pReturn != nullptr);
      if (pReturn)
      {
         assertUnit(pReturn->data == int(99));
         assertUnit(pReturn->pNext == nullptr);
         assertUnit(pReturn->pPrev == p31);
      }

      // teardown
      delete pReturn;
      delete p11;
      delete p26;
      delete p31;
   }
   
   // insert into the middle of the standard fixture with the before option set
   void test_insert_middleBefore()
   {  // setup
      //     p11      p26      p31
      //    +----+   +----+   +----+
      //    | 11 | - | 26 | - | 31 |
      //    +----+   +----+   +----+
      Node * p11, * p26, * p31;
      setupStandardFixture(p11, p26, p31);
      Node * pReturn = nullptr;
      int s(99);
      // exercise
      pReturn = insert(p26, s, false /*after*/);
      // verify
      //      p11     pReturn   p26      p31
      //     +----+   +----+   +----+   +----+
      //     | 11 | - | 99 | - | 26 | - | 31 |
      //     +----+   +----+   +----+   +----+
      assertUnit(p11 != nullptr);
      if (p11)
      {
         assertUnit(p11->data == int(11));
         assertUnit(p11->pPrev == nullptr);
         assertUnit(p11->pNext == pReturn);
      }

      assertUnit(pReturn != nullptr);
      if (pReturn)
      {
         assertUnit(pReturn->data == int(99));
         assertUnit(pReturn->pPrev == p11);
         assertUnit(pReturn->pNext == p26);
      }

      assertUnit(p26 != nullptr);
      if (p26)
      {
         assertUnit(p26->data == int(26));
         assertUnit(p26->pPrev == pReturn);
         assertUnit(p26->pNext == p31);
      }

      assertUnit(p31 != nullptr);
      if (p31)
      {
         assertUnit(p31->data == int(31));
         assertUnit(p31->pPrev == p26);
         assertUnit(p31->pNext == nullptr);
      }
      // teardown
      delete pReturn;
      delete p11;
      delete p26;
      delete p31;
   }
   
   // insert into the middle of the standard fixture with the after option set
   void test_insert_middleAfter()
   {  // setup
      //     p11      p26      p31
      //    +----+   +----+   +----+
      //    | 11 | - | 26 | - | 31 |
      //    +----+   +----+   +----+
      Node * p11, * p26, * p31;
      setupStandardFixture(p11, p26, p31);
      Node * pReturn = nullptr;
      int s(99);
      // exercise
      pReturn = insert(p26, s, true /*after*/);
      // verify
      //      p11       p26    pReturn   p31
      //     +----+   +----+   +----+   +----+
      //     | 11 | - | 26 | - | 99 | - | 31 |
      //     +----+   +----+   +----+   +----+
      assertUnit(p11 != nullptr);
      if (p11)
      {
         assertUnit(p11->data == int(11));
         assertUnit(p11->pPrev == nullptr);
         assertUnit(p11->pNext == p26);
      }

      assertUnit(p26 != nullptr);
      if (p26)
      {
         assertUnit(p26->data == int(26));
         assertUnit(p26->pPrev == p11);
         assertUnit(p26->pNext == pReturn);
      }

      assertUnit(pReturn != nullptr);
      if (pReturn)
      {
         assertUnit(pReturn->data == int(99));
         assertUnit(pReturn->pPrev == p26);
         assertUnit(pReturn->pNext == p31);
      }
      
      assertUnit(p31 != nullptr);
      if (p31)
      {
         assertUnit(p31->data == int(31));
         assertUnit(p31->pPrev == pReturn);
         assertUnit(p31->pNext == nullptr);
      }
      // teardown
      delete pReturn;
      delete p11;
      delete p26;
      delete p31;
   }
  
   /***************************************
    * FIND
    ***************************************/

   // attempt to find an element in an empty linked list
   void test_size_empty()
   {  // setup
      const Node * p = nullptr;
      size_t s;
      // exercise
      s = size(p);
      // verify
      assertUnit(s == 0);
   }  // teardown
   
   // attempt to find an element at the head of the standard fixture
   void test_size_standard()
   {  // setup
      //     p11      p26      p31
      //    +----+   +----+   +----+
      //    | 11 | - | 26 | - | 31 |
      //    +----+   +----+   +----+
      //     pHead
      Node * p11, * p26, * p31;
      setupStandardFixture(p11, p26, p31);
      const Node * pHead = p11;
      size_t s;
      // exercise
      s = size(pHead);
      // verify
      //     p11      p26      p31
      //    +----+   +----+   +----+
      //    | 11 | - | 26 | - | 31 |
      //    +----+   +----+   +----+
      assertUnit(s == 3);
      assertStandardFixture(p11);
      // teardown
      teardownStandardFixture(p11);
   }

   // attempt to find an element at the tail of the standard fixture
   void test_size_standardMiddle()
   {  // setup
      //     p11      p26      p31
      //    +----+   +----+   +----+
      //    | 11 | - | 26 | - | 31 |
      //    +----+   +----+   +----+
      //               pHead
      Node * p11, * p26, * p31;
      setupStandardFixture(p11, p26, p31);
      const Node * pHead = p26;
      size_t s;
      // exercise
      s = size(pHead);
      // verify
      //     p11      p26      p31
      //    +----+   +----+   +----+
      //    | 11 | - | 26 | - | 31 |
      //    +----+   +----+   +----+
      assertUnit(s == 2);
      assertStandardFixture(p11);
      // teardown
      teardownStandardFixture(p11);
   }

      
   /***************************************
    * CLEAR
    ***************************************/
  
   // attempt to free an empty linked list
   void test_clear_nullptr()
   {  // setup
      Node * pList = nullptr;
      // exercise
      clear(pList);
      // verify
      assertUnit(pList == nullptr);
   }  // teardown
   
   // attempt to free a linked list consisting of one node
   void test_clear_one()
   {  // setup
      //     p26
      //    +----+
      //    | 26 |
      //    +----+
      Node * p26 = new Node (26);
      // exercise
      clear(p26);
      // verify
      assertUnit(p26 == nullptr);
   }  // teardown

   // attempt to free the standard fixture
   void test_clear_standard()
   {  // setup
      //     p11      p26      p31
      //    +----+   +----+   +----+
      //    | 11 | - | 26 | - | 31 |
      //    +----+   +----+   +----+
      Node * p11, * p26, * p31;
      setupStandardFixture(p11, p26, p31);
      // exercise
      clear(p11);
      // verify
      assertUnit(p11 == nullptr);
   }  // teardown


   /*************************************************************
    * SETUP STANDARD FIXTURE
    *    +----+   +----+   +----+
    *    | 11 | - | 26 | - | 31 |
    *    +----+   +----+   +----+
    *************************************************************/
   void setupStandardFixture(Node *& p11, Node *& p26, Node *& p31)
   {
      // allocate
      p11 = new Node (11);
      p26 = new Node (26);
      p31 = new Node (31);

      // set next pointers
      p11->pNext = p26;
      p26->pNext = p31;

      // set previous pointers
      p26->pPrev = p11;
      p31->pPrev = p26;
   }


   /*************************************************************
    * VERIFY EMPTY FIXTURE
    *************************************************************/
   void assertEmptyFixtureParameters(const Node * p, int line, const char* function)
   {
      assertIndirect(p != nullptr);

      // Verify empty
      if (p)
      {
         assertIndirect(p->data == int());
         assertIndirect(p->pPrev == nullptr);
         assertIndirect(p->pNext == nullptr);
      }
   }


   /*************************************************************
    * VERIFY STANDARD FIXTURE
    *    +----+   +----+   +----+
    *    | 11 | - | 26 | - | 31 |
    *    +----+   +----+   +----+
    *************************************************************/
   void assertStandardFixtureParameters(const Node * p, int line, const char* function)
   {
      assertIndirect(p != nullptr);

      // Verify 11
      if (p)
      {
         assertIndirect(p->data == int(11));
         assertIndirect(p->pPrev == nullptr);
         assertIndirect(p->pNext != nullptr);

         // verify 26
         if (p->pNext)
         {
            assertIndirect(p->pNext->data == int(26));
            assertIndirect(p->pNext->pPrev == p);
            assertIndirect(p->pNext->pNext != nullptr);

            // verify 31
            if (p->pNext->pNext)
            {
               assertIndirect(p->pNext->pNext->data == int(31));
               assertIndirect(p->pNext->pNext->pPrev == p->pNext);
               assertIndirect(p->pNext->pNext->pNext == nullptr);
            }
         }
      }
   }

   /*************************************************************
    * TEARDOWN STANDARD FIXTURE
    *    +----+   +----+   +----+
    *    |    | - |    | - |    |
    *    +----+   +----+   +----+
    *************************************************************/
   void teardownStandardFixture(Node * pRoot)
   {
      if (nullptr != pRoot)
      {
         if (nullptr != pRoot->pNext && pRoot != pRoot->pNext)
         {
            if (nullptr != pRoot->pNext->pNext && pRoot != pRoot->pNext->pNext && pRoot->pNext != pRoot->pNext->pNext)
               delete pRoot->pNext->pNext;
            delete pRoot->pNext;
         }
         delete pRoot;
      }
   }

};

#endif // DEBUG
