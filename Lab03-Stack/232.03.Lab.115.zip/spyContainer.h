/***********************************************************************
 * Component:
 *    SPY
 * Author:
 *    James Helfrich, PhD. (c) 2022 by Kendall Hunt
 * Summary:
 *    A mock class designed to measure its usage: a spy!
 ************************************************************************/

#pragma once

#include <cassert>
#include <vector>

/*************************************************************
 * SPY CONTAINER
 * A mock container class that records how it was used
 *************************************************************/
template <class T>
class SpyContainer
{
   friend class TestSpyContainer;
private:
   enum {
      DEFAULT_CONSTRUCTOR, // 0
      COPY_CONSTRUCTOR,    // 1
      MOVE_CONSTRUCTOR,    // 2
      COPY_ASSIGN,         // 3
      MOVE_ASSIGN,         // 4
      COPY_PUSH_BACK,      // 5
      MOVE_PUSH_BACK,      // 6
      POP_BACK,            // 7
      READ_BACK,           // 8
      WRITE_BACK,          // 9
      SIZE,                // 10
      EMPTY,               // 11
      DESTRUCTOR,          // 12
      SWAP,                // 13
      NUM_MARKERS          // 14
   };
   std::vector<T> data;

public:
   // default constructor
   SpyContainer() 
   { 
      counters[DEFAULT_CONSTRUCTOR]++; 
   }
   SpyContainer(const T & t)
   {
      counters[DEFAULT_CONSTRUCTOR]++;
      data.push_back(t);
   }

   // copy constructor
   SpyContainer(const SpyContainer& rhs) : data(rhs.data)
   {
      counters[COPY_CONSTRUCTOR]++;
   }

   // move constructor
   SpyContainer(SpyContainer && rhs) : data(std::move(rhs.data))
   {
      counters[MOVE_CONSTRUCTOR]++;
   }

   // destructor
   ~SpyContainer()
   {
      counters[DESTRUCTOR]++;
   }

   // copy assignment operator
   SpyContainer& operator=(const SpyContainer& rhs) noexcept
   {
      data = rhs.data;
      counters[COPY_ASSIGN]++;
      return *this;
   }

   // move assignment operator
   SpyContainer& operator=(SpyContainer&& rhs) noexcept
   {
      data = std::move(rhs.data);
      counters[MOVE_ASSIGN]++;
      return *this;
   }

   // swap member 
   void swap(SpyContainer& rhs) 
   {
      data.swap(rhs.data);
      counters[SWAP]++;
   }

   // empty 
   bool empty() const
   {
      counters[EMPTY]++;
      return data.empty();
   }

   // empty 
   size_t size() const
   {
      counters[SIZE]++;
      return data.size();
   }

   // copy push back
   void push_back(const T& t)
   {
      data.push_back(t);
      counters[COPY_PUSH_BACK]++;
   }

   // move push back
   void push_back(T&& t)
   {
      data.push_back(std::move(t));
      counters[MOVE_PUSH_BACK]++;
   }

   // pop back
   void pop_back()
   {
      data.pop_back();
      counters[POP_BACK]++;
   }

   // read back
   const T& back() const
   {
      counters[READ_BACK]++;
      return data.back();
   }

   // write back
   T& back() 
   {
      counters[WRITE_BACK]++;
      return data.back();
   }

   // reset the counters for a new test
   static void reset()
   {
      for (int i = 0; i < NUM_MARKERS; i++)
         counters[i] = 0;
   }

   static int numDefaultConstruct() { return counters[DEFAULT_CONSTRUCTOR]; }
   static int numCopyConstruct() { return counters[COPY_CONSTRUCTOR]; }
   static int numMoveConstruct() { return counters[MOVE_CONSTRUCTOR]; }
   static int numCopyAssign() { return counters[COPY_ASSIGN]; }
   static int numMoveAssign() { return counters[MOVE_ASSIGN]; }
   static int numCopyPushBack() { return counters[COPY_PUSH_BACK]; }
   static int numMovePushBack() { return counters[MOVE_PUSH_BACK]; }
   static int numPopBack() { return counters[POP_BACK]; }
   static int numReadBack() { return counters[READ_BACK]; }
   static int numWriteBack() { return counters[WRITE_BACK]; }
   static int numSize() { return counters[SIZE]; }
   static int numEmpty() { return counters[EMPTY]; }
   static int numDestructor() { return counters[DESTRUCTOR]; }
   static int numSwap() { return counters[SWAP]; }

   // keep track of how it is used
   static int counters[NUM_MARKERS];
};
